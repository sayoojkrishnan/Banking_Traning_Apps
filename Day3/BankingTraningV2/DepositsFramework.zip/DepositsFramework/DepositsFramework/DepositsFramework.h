//
//  DepositsFramework.h
//  DepositsFramework
//
//  Created by Sayooj Krishnan  on 16/07/21.
//

#import <Foundation/Foundation.h>

//! Project version number for DepositsFramework.
FOUNDATION_EXPORT double DepositsFrameworkVersionNumber;

//! Project version string for DepositsFramework.
FOUNDATION_EXPORT const unsigned char DepositsFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DepositsFramework/PublicHeader.h>


